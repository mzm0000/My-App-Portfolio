package ps.alramy.myappportfolio;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void actionPopularMovies(View view) {
        Intent intent = new Intent(this, Sunshine1Activity.class);
        startActivity(intent);
    }

    public void actionStockHawk(View view) {
        showToast(view);
    }

    public void actionBuildItBigger(View view) {
        showToast(view);
    }

    public void actionMakeYourAppMaterial(View view) {
        showToast(view);
    }

    public void actionUbiquitous(View view) {
        showToast(view);
    }

    public void actionCapstone(View view) {
        showToast(view);
    }

    public void showToast(View view) {
        Toast.makeText(this, ((Button) view).getText().toString(), Toast.LENGTH_SHORT).show();
    }
}
