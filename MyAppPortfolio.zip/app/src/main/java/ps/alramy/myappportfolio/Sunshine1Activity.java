package ps.alramy.myappportfolio;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Sunshine1Activity extends AppCompatActivity {

    ArrayList<String> items;
    ArrayAdapter<String> adapter;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sunshine_v1);

        items = new ArrayList<>();

        items.add("Today - Sunny - 88" + (char) 0x00B0 + "/63" + (char) 0x00B0);
        items.add("Tomorrow - Foggy - 88" + (char) 0x00B0 + "/63" + (char) 0x00B0);
        items.add("Weds - Cloudy - 88" + (char) 0x00B0 + "/63" + (char) 0x00B0);
        items.add("Thurs - Rainy - 88" + (char) 0x00B0 + "/63" + (char) 0x00B0);
        items.add("Fri - Foggy - 88" + (char) 0x00B0 + "/63" + (char) 0x00B0);
        items.add("Sat - Sunny - 88" + (char) 0x00B0 + "/63" + (char) 0x00B0);

        adapter = new ArrayAdapter<>(this, R.layout.list_item_forecast, R.id.tvListItemForecast, items);

        listView = (ListView) findViewById(R.id.lvForecastList);
        listView.setAdapter(adapter);
    }
}
